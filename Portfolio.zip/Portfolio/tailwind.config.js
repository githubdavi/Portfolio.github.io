/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./pages/index.html","./pages/MesProjets.html"],
  theme: {
    extend: {
      height: {
        '600': '600px',
      }
},
  },
  plugins: [],
}

